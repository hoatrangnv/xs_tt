<div class="col-l">
    <iframe width="100%" height="500" src="http://vip.giavang.net/data/aj2.php"></iframe>
</div>