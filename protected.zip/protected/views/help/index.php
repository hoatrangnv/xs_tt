<div class="col-l">
    <div class="box box-suppot">
        <div class="title-bor">
            <h1><strong>Những câu hỏi thường gặp</strong></h1>
        </div>
        <div class="pad10">
            <h2><img width="13" height="13" class="mag-r5" alt="ho tro" src="http://images.ketquaveso.com/images/support.png">Hướng dẫn lấy kết quả xổ số từ hệ thống về websites của bạn! </h2>
            <div class="mag-l18">
                <p style="margin:0">Rất đơn giản, để lấy kết quả xổ số tùy biến: </p>
                <p>Công cụ hoàn toàn miễn phí (100% free) </p>
                <p>Hệ thống ổn định nhất, băng thông lớn load nhẹ nhàng </p>
                <p>Cam kết không chèn quảng cáo, chỉ 1 icon edit trỏ về trang cập nhật mã khi có phiên bản mới. (chỉ hiển thị trong giai đoạn update) </p>
                <p>Tính năng tối ưu: </p>
                <p>+ Có thể lấy trang mặc định tùy ý làm trang chủ phù hợp với website từng khu vực </p>
                <p>+ Có thể tùy chỉnh màu sắc, font chữ phù hợp</p>
                <p>+ Xem được tất cả kết quả xổ số truyền thống toàn quốc trên 1 bảng</p>
                <p>+ Bạn hoàn toàn có thể tùy biến thành 1 websites kết quả xổ số chuyên nghiệp với nhiều trang, trên mỗi trang lấy 1 bảng kqxs mặc định khác nhau theo tỉnh. </p>
                <p>+ Dữ liệu cập nhật nhanh nhất, dung lượng tối ưu phù hợp lấy cho ứng dụng mobile.</p>
            </div>
            <h2><img width="13" height="13" class="mag-r5" alt="ho tro" src="http://images.ketquaveso.com/images/support.png">Cách chơi đề??</h2>
            <div class="mag-l18">
                <p style="margin:0">Đề chỉ gồm 1 giải. Đề được tính là 2 số cuối cùng của giải đặc biệt. Khi bạn đánh đề chỉ soi 2 số cuối của giải đặc biệt xem có trùng không.Nếu trung` với số bạn đánh thì bạn đã trúng</p>
            </div>
            <h2><img width="13" height="13" class="mag-r5" alt="ho tro" src="http://images.ketquaveso.com/images/support.png">Cách chơi loto?</h2>
            <div class="mag-l18">
                <p style="margin-top:0">Lô gồm có 27 con. Lô được tính theo 2 số cuối của tất cả các giải (từ giải đặc biệt đến giải 7) Khi bạn đánh lô bạn sô xem 27 số có con nào trùng với số bạn đánh không. Nếu trùng thì bạn đã trúngKhái niệm về "nháy": Nháy chỉ 1 số về bao nhiêu lần.Nếu số về 2 lần thì gọ là 2 nháy,về 3 lần gọi 3 nháy.... ﻿</p></div>    
            <h2><img width="13" height="13" class="mag-r5" alt="ho tro" src="http://images.ketquaveso.com/images/support.png">Cách ghi lô xiên?</h2>
            <div class="mag-l18">
                <p style="margin:0">Lô xiên là 1 dạng biến thể của lô.Bạn ghi 2 cặp số gọi là xiên 2, 3 cặp số gọi là xiên 3.Nếu các cặp bạn ghi về hết thì bạn trúng,còn nếu chỉ trượt 1 con thôi coi như trượt hếtTheo dõi</p>
            </div>    
            <h2><img width="13" height="13" class="mag-r5" alt="ho tro" src="http://images.ketquaveso.com/images/support.png">Cách chơi xổ số điện toán 123 thế nào?</h2>
            <div class="mag-l18">
                <p style="margin:0">Xổ số điện toán 1-2-3 là loại hình xổ số tự chọn cho phép người mua lựa chọn ba bộ số. Bộ số thứ nhất là số có 1 chữ số từ 0 đến 9, bộ số thứ hai là số có hai chữ số từ 00 đến 99 và bộ số thứ ba là số có ba chữ số từ 000 đến 999. Số dự thưởng điện toán 1-2-3 là số có 6 chữ số bao gồm 3 bộ số : thứ nhất, thứ hai và thứ ba.</p>
            </div>
            <div class="mag-l18">
                <p><img width="8" height="8" class="mag-r5" alt="bullet" src="http://images.ketquaveso.com/images/bulet3.png">Cách chơi xổ số thần tài 4 như thế nào?</p>
                <p style="margin:0">Xổ số thần tài 4 là loại hình xổ số tự chọn, cho phép người mua vé lựa chọn 1 số có 4 chữ số từ 0000 đến 9999 để tham gia dự thưởng.</p>
                <p>Xổ số thần tài mở thưởng hàng ngày.</p>
            </div>
            <p><img width="8" height="8" class="mag-r5" alt="bullet" src="http://images.ketquaveso.com/images/bulet3.png">Cách chơi xổ số điện toán 6X36 thế nào?</p>
            <p style="margin:0">Xổ số điện toán 6x36 là loại hình xổ số tự chọn, cho phép người mua vé thực hiện lựa chọn 6 cặp số, trong đó mỗi cặp số có giới hạn lựa chọn trong khoảng 36 số ( từ số 01 đến số 36) để tham gia dự thưởng. Xổ số điện toán 6x36 mở thưởng định kỳ 2 lần 1 tuần vào thứ 4 và thứ 7. Vé mua sau giờ mở thưởng của kỳ này được tham gia dự thưởng cho kỳ mở thưởng tiếp theo.</p>
        </div>
        <h2><img width="13" height="13" class="mag-r5" alt="ho tro" src="http://images.ketquaveso.com/images/support.png">Hướng Dẫn In Vé Dò Kết Quả Xổ Số</h2>
        <div class="mag-l18">
            <p style="margin:0">xoso.me  Ngoài thế mạnh là một hệ thống websites tường thuật trực tiếp từng giải kết quả xổ số toàn quốc còn cung cấp tính năng In vé dò với mục đích đơn giản nhất cho anh chị em Đại Lý Vé Số in nhanh nhất KQXS trực tiếp hàng ngày hoặc in một ngày bất kỳ chỉ cần 1 cái bấm chuột từ kho dữ liệu chính xác, đầy đủ nhiều năm và cập nhật thường xuyên của xoso.me mà không phải lưu trữ</p>
            <p>• Hướng dẫn thiết lập ban đầu & In: </p>
            <p><b>Yêu cầu:</b> </p>
            <p>Để in KQXS trước tiên bạn phải có 1 máy in đã cài đặt và thiết lập khổ giấy A4.  </p>
            <p>Phiên bản này thiết kế mở rộng tương thích với trình duyệt Internet Explorer, Chrome và Mozilla Firefox </p>
            <p>• Thiết lập trang In (Chỉ làm 1 lần đầu tiên, sau đó máy tính của bạn tự lưu thiết lập này): </p>
            <p>Trên trang bạn thấy dưới mỗi bảng KQXS đều có nút <img src="http://www.minhngoc.com.vn/Images/print.jpg" alt="" align="absMiddle" border="0" hspace="5" />In vé dò <font color="#000000">bạn click vào đó và chọn loại, Hộp thoại <strong>Print</strong> hiện lên &gt; Lần đầu này bạn nhấn <strong>Cancel</strong> &gt; Vào <strong>File</strong> &gt;&gt;<strong>Page Setup... </strong>&gt; Chọn khổ giấy <strong>A4</strong>, chọn canh lề các bên = <strong>0</strong> (nhiều máy in không cho canh lề = 0 thì bạn chọn thông số nhỏ nhất) &gt;&gt; Các thông số khung <strong>Headers and Footers</strong> thiết lập <strong>Empty</strong> &gt;&gt; <strong>Click OK</strong> &gt;đóng. Vào Vào <strong>File</strong> &gt;&gt; <strong>Print Preview...</strong>&gt; Xem lại thử trang in có hợp lý chưa, nếu chưa ok vui lòng xem lại hướng dẫn và xem thêm <strong><font color="#0000ff"><a href="http://www.xosothantai.com/showthread.php?p=494618#post494618" target="_blank">Thiết lập khổ giấy A4 cho máy in</a> </font></strong></font>nếu tất cả ok in test thử 1 tờ.</p>
            <p><font color="#000000">Thế là xong, máy tính của bạn đã lưu lại thiết lập, từ giờ về sau muốn in bảng KQXS bạn chỉ cần Click  <img src="http://www.minhngoc.com.vn/Images/print.jpg" alt="" align="absMiddle" border="0" hspace="5" />In vé dò , chọn loại bản in và <strong>Enter</strong> </font><font color="#000000"><em>(Nếu in Kết Quả Trực Tiếp thì vào xem trực tiếp đến giải cuối cùng Click  </em><em><img src="http://www.minhngoc.com.vn/Images/print.jpg" alt="" align="absMiddle" border="0" hspace="5" /></em>In vé dò <em>và <strong>Enter</strong>).</em></font></p>
            <p>Muốn in nhanh KQXS của 1 ngày bất kỳ: Từ menu <strong>chính </strong>&gt;click vào <strong>In vé dò</strong>&gt; chọn <strong>Miền</strong> &gt; Chọn <strong>ngày</strong> &gt; &gt; Chọn loại &gt;Click <strong>In Vé Dò</strong> &gt; <strong>Enter</strong> là có ngay KQXS của ngày đó.</p>
        </div>    

    </div>
      </div>