<div class="conten-right">
    <h3><strong>Thống kê kết quả xổ số</strong></h3>
    <ul class="stastic-lotery">
<!--        <li><span class="ic"></span><a href="--><?php //echo Url::createUrl("statistic/tansoNhipLoto")?><!--" title="Thống kê tần số nhịp loto">Thống kê tần số nhịp loto</a></li>-->
<!--        <li><span class="ic"></span><a href="--><?php //echo Url::createUrl("statistic/dauduoiLoto")?><!--" title="Thống kê đầu đuôi loto">Thống kê đầu đuôi loto</a></li>-->
<!--        <li><span class="ic"></span><a href="--><?php //echo Url::createUrl("statistic/chukyDacbiet")?><!--" title="Thống kê chu kỳ đặc biệt">Thống kê chu kỳ đặc biệt</a></li>-->
<!--        <li><span class="ic"></span><a href="--><?php //echo Url::createUrl("statistic/dauduoiDacbiet")?><!--" title="Thống kê đầu đuôi đặc biệt">Thống kê đầu đuôi đặc biệt</a></li>-->
<!--        <li><span class="ic"></span><a href="--><?php //echo Url::createUrl("statistic/tansuatBoso")?><!--" title="Thống kê tần suất các bộ số">Thống kê tần suất các bộ số</a></li>-->
<!--        <li><span class="ic"></span><a href="--><?php //echo Url::createUrl("statistic/tansuatCapLoto")?><!--" title="Thống kê tần suất cặp loto">Thống kê tần suất cặp loto</a></li>-->
<!--        <li><span class="ic"></span><a href="--><?php //echo Url::createUrl("statistic/chukyXien")?><!--" title="Thống kê chu kỳ loto xiên">Thống kê chu kỳ loto xiên</a></li>-->
<!--        <li class="nobor"><span class="ic"></span><a href="--><?php //echo Url::createUrl("statistic/tonghop")?><!--" title="Thống kê tổng hợp">Thống kê tổng hợp</a></li>-->

        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/chukyLoto")?>" title="Thống kê chu kỳ loto">Thống kê chu kỳ loto</a></li>
        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/dauduoiLoto")?>" title="Thống kê đầu đuôi loto">Thống kê đầu đuôi loto</a></li>
        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/dacbiet")?>" title="Thống kê giải đặc biệt">Thống kê giải đặc biệt</a></li>
        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/chukyDacbiet")?>" title="Thống kê chu kỳ đặc biệt">Thống kê chu kỳ đặc biệt</a></li>
        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/dauduoiDacbiet")?>" title="Thống kê đầu đuôi đặc biệt">Thống kê đầu đuôi đặc biệt</a></li>
        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/tansuatLoto")?>" title="Thống kê tần suất loto - bộ số">Thống kê tần suất loto - bộ số</a></li>
        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/chukyXien")?>" title="Thống kê chu kỳ loto xiên">Thống kê chu kỳ loto xiên</a></li>
        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/lotoGan")?>" title="Thống kê chu kỳ loto xiên">Thống kê loto gan</a></li>
        <li><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/nhanh")?>" title="Thống kê nhanh">Thống kê nhanh</a></li>
        <li class="nobor"><span class="ic"></span><a href="<?php echo Url::createUrl("statistic/tonghop")?>" title="Thống kê tổng hợp">Thống kê tổng hợp</a></li>
    </ul>
</div>