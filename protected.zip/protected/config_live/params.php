<?php
return array(
	
    'titles' => 'Ket qua ve so hang dau viet nam',
    'keywords' => 'Ket qua, ve so, hang dau, viet nam',
	'descriptions' => 'Ket qua ve so hang dau viet nam',
	'adminEmail' => 'xosothantai@gmail.com',
    
    'base_url'=>'http://xosothantai.vn',
    'domain'=>'xosothantai.vn',
    'http_url'=>'http://xosothantai.vn',
    'static_url'=>'http://xosothantai.vn/themes',
    'urlImages'=>'http://acp.ketquaveso.com/upload/',
    'img_default'=>'http://ketquaveso.com/upload/default/',
    'tiny_url_cp'=>'http://xosothantai.vn/themes/cpanel',
    'static_url_cp'=>'http://xosothantai.vn/themes/cpanel',
    'url_truyen'=>'',
    'hostSolr'=>'192.168.1.109',
    'showsql'=>true, 
	'cache_all'=>true, 
    'fb_app_id'=>'',
    'fb_app_secret'=>'',
);
