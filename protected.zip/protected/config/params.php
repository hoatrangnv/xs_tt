<?php
return array(
	
    'titles' => 'Ket qua ve so hang dau viet nam',
    'keywords' => 'Ket qua, ve so, hang dau, viet nam',
	'descriptions' => 'Ket qua ve so hang dau viet nam',
	'adminEmail' => 'xosothantai@gmail.com',

    'base_url'=>'http://localhost/xosothantai',
    'http_url'=>'http://localhost',
    'domain'=>'localhost',
    'static_url'=>'http://localhost/xosothantai/themes',
    'urlImages'=>'http://localhost/xosothantai/upload/',
    'img_default'=>'http://localhost/xosothantai/upload/default/',
    'tiny_url_cp'=>'http://localhost/xosothantai/themes/cpanel',
    'static_url_cp'=>'http://localhost/xosothantai/themes/cpanel',
    'url_truyen'=>'',
    'hostSolr'=>'localhost',
    'showsql'=>true, 
	'cache_all'=>false, 
    'detect_mobile'=>false,
    'fb_app_id'=>'563037357135810',
    'fb_app_secret'=>'806bed16cfce368417a87c0f5eb2a2c7',
);
