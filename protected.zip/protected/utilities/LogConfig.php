<?php
class LogConfig{
    public static $action = array(
        1=>"Thêm",2=>"Sửa",3=>"Xóa"
    );
    public static $object = array(
        1=>"Admin",
        2=>"Sổ mơ",
        3=>"Tin nhắn",
        4=>"Tin tức",
        5=>"Dự đoán",
        6=>"Thông tin tỉnh",
        7=>"Quay số",
        8=>"Kết quả",
        9=>"Kết quả trong ngày",
        10=>"Soi cầu",
        11=>"Thống kê",
        12=>"Thành viên",
    );
}
