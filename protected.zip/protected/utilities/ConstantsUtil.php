<?php

class ConstantsUtil
{

    const ROW_PER_PAGE= 20;

    const TIME_CACHE_300  = 300;
    const TIME_CACHE_900  = 900;
    const TIME_CACHE_1800 = 1800;
    const TIME_CACHE_3600  = 3600;
    const TIME_CACHE_86400 = 86400;
    
}
?>
